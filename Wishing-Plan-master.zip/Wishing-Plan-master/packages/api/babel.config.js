// This file is used by Babel to configure the transpilation process
// Reason: https://dev.to/_gdelgado/pitfalls-when-adding-turborepo-to-your-project-4cel
module.exports = {
  presets: ["@babel/preset-react"],
};
