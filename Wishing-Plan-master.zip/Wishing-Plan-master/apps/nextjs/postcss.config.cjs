module.exports = require("@wishingplan/tailwind-config/postcss");
