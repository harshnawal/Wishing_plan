/** @type {import("tailwindcss").Config} */
module.exports = {
  presets: [require("@wishingplan/tailwind-config")],
};
