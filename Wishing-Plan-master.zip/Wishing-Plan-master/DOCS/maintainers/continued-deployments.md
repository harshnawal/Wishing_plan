# Continued Deployment

> This document will become the place to find information on how we will carry out the deployment of our applications with changes over time.
> This document will be updated as we learn more about the deployment process.
